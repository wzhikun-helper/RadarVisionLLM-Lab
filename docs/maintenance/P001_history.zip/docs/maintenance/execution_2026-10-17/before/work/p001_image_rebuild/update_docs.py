from pathlib import Path

root=Path('D:/RadarVisionLLM-Lab')
out=root/'presentations/P001_Radar_Detection_Prerequisite'
backup=out/'backups/20261017_before_image_rebuild'
corrections='''

## 2026-10-17：新视觉稿与原生重建记录

原指定输入目录不存在，经用户授权创建并继续，本次使用内置 `image_gen` 逐张新生成 9 张完整幻灯片视觉稿，再按图原生重建。不是接收已存在的用户 GPT Image 2 原图。工具未公开可独立验证的模型版本，不将其虚称为已确认的 GPT Image 2。
完整提示词：`D:/RadarVisionLLM-Lab/presentations/P001_slide_images/generation_prompts.json`。
图片清单和顺序：同目录 `image_manifest.json`。按文件前缀、画面标题和页脚 01–09 交叉确认，无待定顺序。
9 张原图均为 **1672×941 px**，近似 16:9，宽高比与严格 16:9 相差约 **0.053%**。PPT 为严格 **1280×720**（12192000×6858000 EMU）。原图未裁切或拉伸。

### 逐页问题与修正（保留原图，不静默改写）

| 页 | 原图观察 | 原生 PPT 的处理 / 依据 |
|---|---|---|
| 1 | 传感器有立体外壳，点云细节较密 | 保留三段布局，传感器简化成可编辑几何，点位重设。点数与形状均非实测。 |
| 2 | Doppler 用频率斜坡叠加相位标记，易与距离混淆；RCS 箭头主要离开雷达方向 | 用跨 Chirp 相位圆替代 Doppler 斜坡，RCS 显示返回雷达的散射。依据 S2、S4。返回幅度仍不等于已校准 RCS。 |
| 3 | 连续渐变图例和立体阴影 | 纯色三类点和独立大小示意，不假定实测速值对应。 |
| 4 | 标题误加 P004；Cube 固定标 Range–Doppler–Azimuth；多径小路径含混 | 移除误前缀，Cube 不固定为唯一轴定义（S7），以准确短文本解释多径，省略含混路径。 |
| 5 | 装饰性 RD 热图、响应和阈值 | 按相同布局重绘合成响应与变化门限，保留七节点顺序和顺序可变说明，不声称为 P001 固件。 |
| 6 | Pillar 高度范围不一致，坐标轴标签有重复 | 柱体采用相同 z 范围，不沿 z 分层；清理坐标。保留上四阶段 / 下三阶段及回折连接。依据 S5。 |
| 7 | 标成 BEV 的小图画成透视立体框，缺少英文扫描标题 | 用同一 XY 俯视坐标中的矩形表示动态错位，补充 Single / 3-Scan / 5-Scan 标题。依据 S1 §IV-B。 |
| 8 | 英文标题有额外图像笔画，参数文字重复 | 用原生文字清理，保留两框、体积 IoU、概念 PR、AP 面积及 TP 公式。 |
| 9 | Pillar 图画成沿 z 分层的不同高度块，附带灯泡等装饰 | 用无 z 分层、相同高度范围的柱替代，去除装饰，保留六阶段链与时序输入。依据 S5。 |

所有参考图片保留原始状态用于核对。最终 PPT **页内图片元素为 0，整页图片为 0**。文字、点、图框、网格、PR 曲线和箭头均为原生可编辑对象。部分曲线 / 线框为自定义矢量路径，可编辑顶点，不是带工作簿的 Chart。公式为可编辑文本，不是 OMML 公式对象。
这是按语义与主要布局重建，**不声称逐像素复刻或自动矢量化**。字号、点位、传感器外形和局部布线作了适配。

### 讲义与核查范围

逐页备注复用此前已核读的原始资料，更新了 Doppler 相位图、PointPillars 读图顺序和 BEV 说明。9 份备注写入 PPT，同时输出 Markdown 备份。
本次核对项目结项笔记中关于点特征、多 scan、IoU 的正式补充，没有加入论文实验结果表。原有学习笔记、图库和实验记录未修改。
用户另附的 `C:/Users/26407/Desktop/雷视融合论文/P001/P001｜Multi-Class Road User Detection With 3+1D Radar in the View-of-Delft Dataset.pdf` 未被假定为原始期刊 PDF；技术事实仍以此前已核读的 8 页期刊原件与项目正式核查补充为准。
P001 底层专有 DSP、确切 AP recall 采样版本仍未确认，未作为已知实现写入。
'''
(out/'sources.md').write_text((backup/'sources.md').read_text(encoding='utf-8')+corrections,encoding='utf-8')
readme='''# P001 预备知识：视觉稿原生重建版

严格 9 页、16:9。输入是本任务逐张新生成的 9 张独立视觉稿，最终 PPT 按图重建，未插入整页图片。

## 文件与目录

- `P001_Prerequisite_Knowledge.pptx`：原生可编辑课件。
- `P001_Speaker_Notes.md`：逐页中文讲义，与内嵌 Speaker Notes 对应，含学习目标、原理、读图、公式、例子、误区、论文联系与来源。
- `sources.md`：原始资料、公式条件、输入说明与逐页技术修正。
- `generate_ppt.py`：Python 启动器。
- `generate_ppt.mjs`：当前 presentations 技能的完整 JS 原生作者脚本。
- `assets/notes_image_rebuild.json`：作者脚本读取的讲稿。
- `assets/slide-01.png` 至 `slide-09.png`：最终 PowerPoint 分页渲染。
- `assets/validation.json`：本次实际校验记录。

图片输入目录：`D:/RadarVisionLLM-Lab/presentations/P001_slide_images/`。
01_Cover、02_FMCW、03_Radar_Dimensions、04_Radar_Point_Cloud、05_Radar_Pipeline、06_PointPillars、07_Temporal_Accumulation、08_Detection_Metrics、09_Knowledge_Summary（均为 PNG）。顺序通过编号、标题与页码确认。
原目录不存在，经用户授权创建后，用内置 image_gen 先生成封面，再逐张引用封面风格生成其余页面。工具未公开可独立验证的模型版本，不声称已验证为 GPT Image 2。
全部原图为 1672×941，约 16:9；PPT 严格 1280×720。原图未裁切，完整提示词与尺寸清单保存在图片目录。

## 可编辑性与视觉对应

页内全部标题、注释、公式文本、坐标轴、点云、雷达形状、三维框、Pillar、特征单元、节点、箭头和 PR 曲线均为原生对象。**图片元素 0 个，整页背景图 0 个**。每个点可单独选择，部分线框 / 曲线为自定义路径，可改色和编辑顶点。移动整图可先框选后组合。
公式是可编辑文本，不是 OMML；PR 为路径而非带 Excel 数据源的统计图表。图中的点、谱峰和曲线都是 Conceptual Illustration，不能当作实验数据。
保留参考图主要布局与配色，不声称逐像素一致。传感器外壳、点云采样与局部布线简化，移除渐变、阴影和不必要装饰。原图中的 P004 前缀、Doppler 示意、Pillar 分层与 BEV 透视混用等问题，在 sources.md 逐页说明后修正。

## 字体与讲稿

Microsoft YaHei（微软雅黑），本机已安装但未嵌入。其他设备应安装对应字体或选择中文替代字体后检查。完整中文讲义可在 PowerPoint 备注窗格查看，Markdown 是独立备份。

## 内容索引

1. 封面；2. FMCW；3. 3+1D；4. Radar Point Cloud；5. 信号处理链；6. PointPillars；7. Temporal Accumulation；8. Metrics；9. Knowledge Summary。

## 复现

```powershell
python generate_ppt.py
```

需要 Codex bundled Node 与 `@oai/artifact-tool`。`P001_NODE` 可指定 Node，`RUNTIME_NODE_MODULES` 可指定包含该包的 node_modules。Python 文件负责启动 JS，不再使用 python-pptx 写包。此专用依赖不是普通 pip 包，纯 Python 环境无法独立复现。
生成器重跑会先备份已有 PPT。九张 AI 原图的精确像素不由作者脚本重生成，但完整提示词已保存。PPT 原生对象和固定随机点位可复现。

## 备份与边界

旧版课件、脚本、讲稿、来源和所有旧预览均保存至 `backups/20261017_before_image_rebuild/`。未修改原论文学习笔记、图库或实验记录；未执行 git add、commit 或 push。
未核实的底层 DSP 与原版 AP 采样细节在来源文件中声明，未当作论文具体实现写入。最终 PowerPoint 渲染、边界与独立编辑性验证结果见 assets/validation.json。
'''
(out/'README.md').write_text(readme,encoding='utf-8')
(root/'presentations/P001_slide_images/README.md').write_text('''# P001 独立幻灯片视觉参考

9 张 PNG，每张均是独立完整幻灯片，未制作九宫格或拼图。01 封面先生成，其余按封面风格逐张生成。原图不可编辑，作为原生 PPT 的视觉参考。
image_manifest.json 记录尺寸与顺序，generation_prompts.json 记录全部提示词及内置 image_gen 模式。工具未公开可独立验证的模型版本。
原图存在若干生成错误，完整问题与原生 PPT 的修正在 ../P001_Radar_Detection_Prerequisite/sources.md 逐页列明。原图保持原始状态，不可冒充论文原图或真实实验数据。
''',encoding='utf-8')
print('Docs updated; originals preserved.')
