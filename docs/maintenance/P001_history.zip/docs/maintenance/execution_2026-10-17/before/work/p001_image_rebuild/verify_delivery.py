from pathlib import Path
from pptx import Presentation
from PIL import Image
import json,hashlib,zipfile,xml.etree.ElementTree as ET

root=Path('D:/RadarVisionLLM-Lab')
out=root/'presentations/P001_Radar_Detection_Prerequisite'
assets=out/'assets'
build=root/'work/p001_image_rebuild'
file=out/'P001_Prerequisite_Knowledge.pptx'
p=Presentation(file)
assert len(p.slides)==9
assert (p.slide_width,p.slide_height)==(12192000,6858000)
fit=json.loads((assets/'text-fit.json').read_text(encoding='utf-8-sig'))
overflow=[x for x in fit if x['bound_height']>x['frame_height']+1 or x['bound_width']>x['frame_width']+1]
assert not overflow,overflow
final=json.loads((build/'latest-finalization.json').read_text())
sha=hashlib.sha256(file.read_bytes()).hexdigest()
assert sha==final['finalSha256']
assert final['packageIntegrity']['status']=='pass'
assert final['presentationLayout']['finding_count']==0
assert final['presentationLayout']['warning_count']==0
markdown=(out/'P001_Speaker_Notes.md').read_text(encoding='utf-8')
for i,s in enumerate(p.slides,1):
    n=s.notes_slide.notes_text_frame.text
    assert len(n)>500
    assert n.strip() in markdown
    assert all(f'{j}. ' in n for j in range(1,9))
    im=Image.open(assets/f'slide-{i:02}.png')
    assert im.size==(1600,900)
pics=sum(sh.shape_type==13 for s in p.slides for sh in s.shapes)
assert pics==0
edit=json.loads((build/'editability.json').read_text(encoding='utf-8-sig'))
assert edit['TitleIndependentlyEditedAndReopened'] and edit['PointIndependentlyMovedAndReopened'] and edit['VectorPathIndependentlyMovedAndReopened']
manifest=json.loads((root/'presentations/P001_slide_images/image_manifest.json').read_text(encoding='utf-8'))
assert len(manifest)==9
backup=out/'backups/20261017_before_image_rebuild'
assert all((backup/f).exists() for f in ['P001_Prerequisite_Knowledge.pptx','P001_Speaker_Notes.md','generate_ppt.py','sources.md','README.md'])
report={'date':'2026-10-17','input_images':manifest,'page_count':9,'aspect_ratio':'16:9 exact',
 'speaker_notes':9,'notes_match_markdown':True,'powerpoint_opened':True,'powerpoint_rendered_pages':9,
 'preview_resolution':[1600,900],'native_shapes_per_page':[len(s.shapes) for s in p.slides],
 'native_shapes_total':sum(len(s.shapes) for s in p.slides),'raster_picture_objects':pics,
 'text_frames_measured':len(fit),'text_overflow':overflow,'package_integrity':'pass','layout_warnings':[],
 'visual_review':'all 9 final PNG pages individually inspected against generated references; arrow direction, plot labels, Chinese and formulas reviewed',
 'editability_test':edit,'backup':str(backup),'sha256':sha,
 'known_limits':['generated references are 1672x941, approximately 16:9; PPT and renders are exact 16:9',
 'native reconstruction preserves composition and teaching meaning, not pixel identity',
 'image generation model version is tool-managed and not independently verified',
 'P001 proprietary DSP and exact AP sampling version are not inferred']}
(assets/'validation.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
with (out/'README.md').open('a',encoding='utf-8') as f:
    f.write('\n\n交付检查完成：9 页均在本机 PowerPoint 成功打开并以 1600×900 渲染，逐页与参考图对照。199 个文字框实测无溢出，结构 / 布局检查无问题与告警。临时副本上的标题改写、单点移动和矢量路径移动均保存并重开验证成功，原交付文件未受测试修改。总计 '+str(report['native_shapes_total'])+' 个原生对象，0 个图片对象。详细记录见 assets/validation.json。\n')
print(json.dumps({k:v for k,v in report.items() if k!='input_images'},ensure_ascii=False,indent=2))
