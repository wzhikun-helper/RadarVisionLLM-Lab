from pathlib import Path
from PIL import Image,ImageChops,ImageStat
import json
root=Path('D:/RadarVisionLLM-Lab')
build=root/'work/p001_visual_exact'
r=json.loads((build/'verification.json').read_text(encoding='utf-8'))
metrics=[]
for i,name in enumerate(r['order'],1):
    src=Image.open(root/'presentations/P001_slide_images'/name).convert('RGB')
    preview=Image.open(build/f'renders/slide-{i:02}.png').convert('RGB')
    # Comparison only: resample the renderer output to source size; originals are not modified.
    resized=preview.resize(src.size,Image.Resampling.LANCZOS)
    diff=ImageChops.difference(src,resized)
    stat=ImageStat.Stat(diff)
    mae=sum(stat.mean)/3
    metrics.append({'page':i,'render_pixels':list(preview.size),'comparison_rgb_MAE':round(mae,4)})
    assert mae<3,(i,mae)
r['powerpoint_opened']=True
r['powerpoint_rendered_pages']=9
r['render_comparison']=metrics
r['comparison_note']='Original bytes match exactly. Render comparison includes renderer interpolation and subpixel side margins; it is not a claim of identical preview raster pixels.'
r['visual_review']='All nine rendered pages inspected individually; no crop, stretched geometry, added labels, or missing image content.'
(build/'verification.json').write_text(json.dumps(r,ensure_ascii=False,indent=2),encoding='utf-8')
report=Path(r['output']).with_suffix('.verification.json')
report.write_text(json.dumps(r,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps(metrics,indent=2))
print(report)
