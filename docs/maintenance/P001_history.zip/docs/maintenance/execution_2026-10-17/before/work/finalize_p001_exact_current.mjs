import fs from 'node:fs/promises';
import {finalizePresentation} from 'file:///C:/Users/26407/.codex/plugins/cache/openai-primary-runtime/presentations/26.1013.11914/skills/presentations/container_tools/artifact_tool_utils.mjs';
const build=(await fs.readFile('D:/RadarVisionLLM-Lab/work/p001_exact_current_build.txt','utf8')).trim();
const result=await finalizePresentation(JSON.parse(await fs.readFile(build+'/finalize-options.json','utf8')));
console.log(JSON.stringify({output:result.finalPath,sha256:result.finalSha256}));
