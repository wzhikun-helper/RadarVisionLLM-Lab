from pathlib import Path
import json,hashlib,zipfile,posixpath
from pptx import Presentation
from PIL import Image
from io import BytesIO

root=Path('D:/RadarVisionLLM-Lab')
build=root/'work/p001_visual_exact'
result=json.loads((build/'finalization.json').read_text())
file=Path(result['finalPath'])
manifest=json.loads((build/'manifest.json').read_text())
p=Presentation(file)
assert len(p.slides)==len(manifest)==9
assert (p.slide_width,p.slide_height)==(12192000,6858000)
checks=[]
for i,(s,m) in enumerate(zip(p.slides,manifest),1):
    assert len(s.shapes)==1,(i,len(s.shapes))
    pic=s.shapes[0]
    assert pic.shape_type==13
    original=(root/'presentations/P001_slide_images'/m['filename']).read_bytes()
    embedded=pic.image.blob
    byte_identical=embedded==original
    assert byte_identical,(i,'Embedded media must match original bytes')
    assert all(abs(getattr(pic,k))<1e-7 for k in ['crop_left','crop_right','crop_top','crop_bottom'])
    assert abs(pic.width/pic.height-m['width']/m['height'])<1e-6
    assert pic.top==0 and pic.height==p.slide_height
    margin=(p.slide_width-pic.width)/2
    checks.append({'page':i,'filename':m['filename'],'pixels':[m['width'],m['height']],
      'one_picture_only':True,'source_sha256':hashlib.sha256(original).hexdigest(),
      'embedded_sha256':hashlib.sha256(embedded).hexdigest(),'embedded_bytes_identical':byte_identical,
      'crop':[pic.crop_left,pic.crop_top,pic.crop_right,pic.crop_bottom],
      'frame_emu':[pic.left,pic.top,pic.width,pic.height],
      'left_margin_at_1280_px':pic.left/9525,'right_margin_at_1280_px':(p.slide_width-pic.left-pic.width)/9525})
report={'input_directory':str(root/'presentations/P001_slide_images'),
 'output':str(file),'image_count':9,'slide_count':9,'slide_size_emu':[p.slide_width,p.slide_height],
 'order':[m['filename'] for m in manifest],
 'excluded_non_image_files':['README.md','generation_prompts.json','image_manifest.json'],
 'all_original_media_bytes_identical':True,'no_extra_visible_objects':True,
 'fit':'Full height, original aspect ratio, horizontal centering; no crop or stretch',
 'ratio_limit':'1672x941 is approximately 16:9; each side has ~0.3401px white canvas remainder at 1280x720',
 'checks':checks}
(build/'verification.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps({k:v for k,v in report.items() if k!='checks'},ensure_ascii=False,indent=2))
