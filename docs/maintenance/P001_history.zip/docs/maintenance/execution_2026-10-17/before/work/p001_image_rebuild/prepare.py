from pathlib import Path
from PIL import Image
import json

root=Path('D:/RadarVisionLLM-Lab')
out=root/'presentations/P001_Radar_Detection_Prerequisite'
backup=out/'backups/20261017_before_image_rebuild'
parts=(backup/'P001_Speaker_Notes.md').read_text(encoding='utf-8').split('\n\n---\n\n')
parts[0]=parts[0].split('\n\n',1)[1]
assert len(parts)==9
parts[1]=parts[1].replace('右上 Range–Doppler 图的两个坐标分别是距离和径向速度。','右上三个相位圆表示同一距离单元在相邻 Chirp 间的相位推进，不把斜坡图本身误当作相位。')
parts[5]=parts[5].replace('沿中间回折连线转到左下 pseudo-image，接着看 backbone、head 和右下 3D 框。','看右上 pseudo-image 后，沿回折连线转到左下 backbone，再到 head 和右下 3D 框。')
parts[6]=parts[6].replace('右边的三个水平框','右边同一 BEV 坐标下的三个俯视矩形框')
(out/'assets/notes_image_rebuild.json').write_text(json.dumps(parts,ensure_ascii=False,indent=2),encoding='utf-8')
files=sorted((root/'presentations/P001_slide_images').glob('*.png'))
assert len(files)==9
manifest=[]
for i,p in enumerate(files,1):
    with Image.open(p) as im:
        manifest.append({'page':i,'filename':p.name,'width':im.width,'height':im.height,
                         'aspect_ratio':im.width/im.height,'order_confirmed':True,'source':'built-in image_gen, generated in this task'})
(root/'presentations/P001_slide_images/image_manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps(manifest,ensure_ascii=False,indent=2))
