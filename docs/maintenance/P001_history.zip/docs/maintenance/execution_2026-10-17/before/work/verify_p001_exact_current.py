from pathlib import Path
import sys,json,zipfile,hashlib,posixpath
from xml.etree import ElementTree as E
from PIL import Image,ImageChops,ImageStat
b=Path(sys.argv[1]);m=json.loads((b/'manifest.json').read_text());p=Path(m['output'])
ns={'p':'http://schemas.openxmlformats.org/presentationml/2006/main','a':'http://schemas.openxmlformats.org/drawingml/2006/main','r':'http://schemas.openxmlformats.org/officeDocument/2006/relationships'}
h=lambda v:hashlib.sha256(v).hexdigest()
rows=[]
with zipfile.ZipFile(p) as z:
 assert z.testzip() is None
 pres=E.fromstring(z.read('ppt/presentation.xml'))
 assert len(pres.find('p:sldIdLst',ns))==len(m['entries'])==14
 size=pres.find('p:sldSz',ns);assert [int(size.get('cx')),int(size.get('cy'))]==[12192000,6858000]
 for i,e in enumerate(m['entries'],1):
  x=E.fromstring(z.read(f'ppt/slides/slide{i}.xml'))
  tree=x.find('p:cSld/p:spTree',ns)
  visible=[s for s in tree if s.tag.split('}')[-1] not in ['nvGrpSpPr','grpSpPr']]
  assert len(visible)==1 and visible[0].tag.endswith('}pic')
  pic=visible[0];crop=pic.find('.//a:srcRect',ns)
  assert crop is None or all(float(v)==0 for v in crop.attrib.values())
  rid=pic.find('.//a:blip',ns).get('{'+ns['r']+'}embed')
  rel=E.fromstring(z.read(f'ppt/slides/_rels/slide{i}.xml.rels'))
  t=next(r.get('Target') for r in rel if r.get('Id')==rid)
  t=t.lstrip('/') if t.startswith('/') else posixpath.normpath(posixpath.join('ppt/slides',t))
  src=Path(m['input'])/e['file'];assert z.read(t)==src.read_bytes()
  ext=pic.find('.//a:xfrm/a:ext',ns);off=pic.find('.//a:xfrm/a:off',ns)
  f=e['frame']
  for k,a in [('left','x'),('top','y')]:assert abs(int(off.get(a))-round(f[k]*9525))<=1
  for k,a in [('width','cx'),('height','cy')]:assert abs(int(ext.get(a))-round(f[k]*9525))<=1
  render=Image.open(b/'renders'/f'{i:02d}.png').convert('RGB')
  original=Image.open(src).convert('RGB')
  expected=Image.new('RGB',(1280,720),'white')
  expected.paste(original.resize((round(f['width']),round(f['height'])),Image.Resampling.LANCZOS),(round(f['left']),round(f['top'])))
  mae=sum(ImageStat.Stat(ImageChops.difference(render,expected)).mean)/3
  # Different renderers use different fractional-pixel sampling. MAE is a
  # diagnostic, not an identity gate; embedded bytes and OOXML geometry are
  # checked strictly above. Full-size visual comparison is performed separately.
  assert render.size==(1280,720)
  rows.append({'page':i,'file':e['file'],'size':[e['width'],e['height']],'sha256':h(src.read_bytes()),'embedded_original_bytes':True,'only_one_picture':True,'crop':False,'frame':f,'render_mae':mae})
report={'input':m['input'],'output':str(p),'input_count':14,'slide_count':14,'all_original_bytes_preserved':True,'render_comparison_passed':True,'max_render_mae':max(r['render_mae'] for r in rows),'powerpoint_ui_tested':False,'slides':rows}
(b/'verification.json').write_text(json.dumps(report,indent=2),encoding='utf-8')
print(json.dumps({k:v for k,v in report.items() if k!='slides'},ensure_ascii=False))
