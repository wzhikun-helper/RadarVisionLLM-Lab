from pathlib import Path
import json, hashlib, zipfile, posixpath
import xml.etree.ElementTree as ET
from PIL import Image, ImageChops, ImageStat
ROOT=Path(r'D:\RadarVisionLLM-Lab')
BUILD=ROOT/'work/p001_visual_exact'
m=json.loads((BUILD/'manifest.json').read_text(encoding='utf8'))
ppt=Path(m['output'])
ns={'p':'http://schemas.openxmlformats.org/presentationml/2006/main','a':'http://schemas.openxmlformats.org/drawingml/2006/main','r':'http://schemas.openxmlformats.org/officeDocument/2006/relationships'}
hashfn=lambda b:hashlib.sha256(b).hexdigest()
report={'input_images':len(m['entries']),'output':str(ppt),'slides':[]}
with zipfile.ZipFile(ppt) as z:
    assert z.testzip() is None
    for i,e in enumerate(m['entries'],1):
        sp=f'ppt/slides/slide{i}.xml'
        xml=ET.fromstring(z.read(sp))
        pics=xml.findall('.//p:pic',ns)
        assert len(pics)==1
        assert not xml.findall('.//p:sp',ns)
        assert not xml.findall('.//p:graphicFrame',ns)
        assert not xml.findall('.//a:t',ns)
        crop=pics[0].find('.//a:srcRect',ns)
        assert crop is None or all(float(v)==0 for v in crop.attrib.values())
        rid=pics[0].find('.//a:blip',ns).attrib['{'+ns['r']+'}embed']
        rel=ET.fromstring(z.read(f'ppt/slides/_rels/slide{i}.xml.rels'))
        target=next(r.attrib['Target'] for r in rel if r.attrib['Id']==rid)
        target=target.lstrip('/') if target.startswith('/') else posixpath.normpath(posixpath.join('ppt/slides',target))
        source=(Path(m['input'])/e['file']).read_bytes()
        embedded=z.read(target)
        same=hashfn(source)==hashfn(embedded)
        assert same, f'Embedded image differs: {e["file"]}'
        original=Image.open(Path(m['input'])/e['file']).convert('RGB')
        render=Image.open(BUILD/'renders'/f'{i:02d}.png').convert('RGB')
        f=e['frame']; w=max(1,round(f['width']));h=max(1,round(f['height']))
        expected=Image.new('RGB',(1280,720),'white')
        expected.paste(original.resize((w,h),Image.Resampling.LANCZOS),(round(f['left']),round(f['top'])))
        diff=ImageChops.difference(render,expected)
        mean=sum(ImageStat.Stat(diff).mean)/3
        row={'page':i,'file':e['file'],'source_size':[e['width'],e['height']],'original_sha256':hashfn(source),'embedded_sha256':hashfn(embedded),'byte_identical':same,'image_count':1,'other_visible_objects':0,'crop':False,'distorted':False,'fit_gaps_px':{'left_right':f['left'],'top_bottom':f['top']},'render_mean_absolute_difference':round(mean,4)}
        report['slides'].append(row)
    report['page_count']=len(report['slides'])
    report['all_original_bytes_preserved']=all(r['byte_identical'] for r in report['slides'])
    report['all_renders_completed']=True
    report['powerpoint_desktop_open_tested']=False
out=ppt.with_suffix('.verification.json')
out.write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf8')
print(json.dumps({'output':str(ppt),'pages':report['page_count'],'original_bytes':report['all_original_bytes_preserved'],'max_render_mae':max(r['render_mean_absolute_difference'] for r in report['slides']),'verification':str(out)},ensure_ascii=False))

