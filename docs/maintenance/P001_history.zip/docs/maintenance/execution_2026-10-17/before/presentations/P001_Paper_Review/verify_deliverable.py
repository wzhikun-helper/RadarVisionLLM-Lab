"""Read-only package checks and contact sheets for review."""
from pathlib import Path
from zipfile import ZipFile
import json
import re
import xml.etree.ElementTree as ET
from PIL import Image

here = Path(__file__).resolve().parent
root = here.parents[1]
images = root / 'presentations/P001_paper_review_images'
visuals = sorted(images.glob('*.png'))
assert len(visuals) == 14, len(visuals)
with ZipFile(here / 'P001_Paper_Review.pptx') as package:
    names = package.namelist()
    slides = sorted((n for n in names if re.fullmatch(r'ppt/slides/slide\d+\.xml', n)), key=lambda n: int(re.search(r'(\d+)\.xml', n).group(1)))
    assert len(slides) == 14
    charts = [n for n in names if re.search(r'/charts/chart\d+\.xml$', n)]
    assert len(charts) == 3
    assert len([n for n in names if n.endswith('.xlsx')]) == 3
    assert len([n for n in names if re.fullmatch(r'ppt/notesSlides/notesSlide\d+\.xml', n)]) == 14
    ns = {'p': 'http://schemas.openxmlformats.org/presentationml/2006/main'}
    pictures = [len(ET.fromstring(package.read(n)).findall('.//p:pic', ns)) for n in slides]
    assert pictures == [0] * 8 + [1, 1] + [0] * 4, pictures
    assert len(ET.fromstring(package.read(slides[11])).findall('.//{http://schemas.openxmlformats.org/drawingml/2006/main}tbl')) == 1
    report = {'slide_count': 14, 'visual_reference_count': 14, 'native_charts': 3, 'native_tables': 1, 'notes_slides': 14, 'raster_pictures_per_slide': pictures, 'full_slide_raster_pages': 0, 'powerpoint_desktop_tested': False}
private = root / 'work/p001_paper_review'
private.mkdir(parents=True, exist_ok=True)
(private / 'deliverable-check.json').write_text(json.dumps(report, indent=2), encoding='utf-8')
for paths, filename in [(visuals, 'visual-reference-overview.png'), (sorted((here / 'assets').glob('slide-*.png')), 'final-overview.png')]:
    canvas = Image.new('RGB', (1600, 7 * 450), 'white')
    for i, p in enumerate(paths):
        im = Image.open(p).convert('RGB')
        im.thumbnail((800, 450))
        canvas.paste(im, ((i % 2) * 800, (i // 2) * 450))
    canvas.save(private / filename)
print(json.dumps(report, ensure_ascii=False))
