# P001 预备知识：视觉稿原生重建版

严格 9 页、16:9。输入是本任务逐张新生成的 9 张独立视觉稿，最终 PPT 按图重建，未插入整页图片。

## 文件与目录

- `P001_Prerequisite_Knowledge.pptx`：原生可编辑课件。
- `P001_Speaker_Notes.md`：逐页中文讲义，与内嵌 Speaker Notes 对应，含学习目标、原理、读图、公式、例子、误区、论文联系与来源。
- `sources.md`：原始资料、公式条件、输入说明与逐页技术修正。
- `generate_ppt.py`：Python 启动器。
- `generate_ppt.mjs`：当前 presentations 技能的完整 JS 原生作者脚本。
- `assets/notes_image_rebuild.json`：作者脚本读取的讲稿。
- `assets/slide-01.png` 至 `slide-09.png`：最终 PowerPoint 分页渲染。
- `assets/validation.json`：本次实际校验记录。

图片输入目录：`D:/RadarVisionLLM-Lab/presentations/P001_slide_images/`。
01_Cover、02_FMCW、03_Radar_Dimensions、04_Radar_Point_Cloud、05_Radar_Pipeline、06_PointPillars、07_Temporal_Accumulation、08_Detection_Metrics、09_Knowledge_Summary（均为 PNG）。顺序通过编号、标题与页码确认。
原目录不存在，经用户授权创建后，用内置 image_gen 先生成封面，再逐张引用封面风格生成其余页面。工具未公开可独立验证的模型版本，不声称已验证为 GPT Image 2。
全部原图为 1672×941，约 16:9；PPT 严格 1280×720。原图未裁切，完整提示词与尺寸清单保存在图片目录。

## 可编辑性与视觉对应

页内全部标题、注释、公式文本、坐标轴、点云、雷达形状、三维框、Pillar、特征单元、节点、箭头和 PR 曲线均为原生对象。**图片元素 0 个，整页背景图 0 个**。每个点可单独选择，部分线框 / 曲线为自定义路径，可改色和编辑顶点。移动整图可先框选后组合。
公式是可编辑文本，不是 OMML；PR 为路径而非带 Excel 数据源的统计图表。图中的点、谱峰和曲线都是 Conceptual Illustration，不能当作实验数据。
保留参考图主要布局与配色，不声称逐像素一致。传感器外壳、点云采样与局部布线简化，移除渐变、阴影和不必要装饰。原图中的 P004 前缀、Doppler 示意、Pillar 分层与 BEV 透视混用等问题，在 sources.md 逐页说明后修正。

## 字体与讲稿

Microsoft YaHei（微软雅黑），本机已安装但未嵌入。其他设备应安装对应字体或选择中文替代字体后检查。完整中文讲义可在 PowerPoint 备注窗格查看，Markdown 是独立备份。

## 内容索引

1. 封面；2. FMCW；3. 3+1D；4. Radar Point Cloud；5. 信号处理链；6. PointPillars；7. Temporal Accumulation；8. Metrics；9. Knowledge Summary。

## 复现

```powershell
python generate_ppt.py
```

需要 Codex bundled Node 与 `@oai/artifact-tool`。`P001_NODE` 可指定 Node，`RUNTIME_NODE_MODULES` 可指定包含该包的 node_modules。Python 文件负责启动 JS，不再使用 python-pptx 写包。此专用依赖不是普通 pip 包，纯 Python 环境无法独立复现。
生成器重跑会先备份已有 PPT。九张 AI 原图的精确像素不由作者脚本重生成，但完整提示词已保存。PPT 原生对象和固定随机点位可复现。

## 备份与边界

旧版课件、脚本、讲稿、来源和所有旧预览均保存至 `backups/20261017_before_image_rebuild/`。未修改原论文学习笔记、图库或实验记录；未执行 git add、commit 或 push。
未核实的底层 DSP 与原版 AP 采样细节在来源文件中声明，未当作论文具体实现写入。最终 PowerPoint 渲染、边界与独立编辑性验证结果见 assets/validation.json。


交付检查完成：9 页均在本机 PowerPoint 成功打开并以 1600×900 渲染，逐页与参考图对照。199 个文字框实测无溢出，结构 / 布局检查无问题与告警。临时副本上的标题改写、单点移动和矢量路径移动均保存并重开验证成功，原交付文件未受测试修改。总计 2126 个原生对象，0 个图片对象。详细记录见 assets/validation.json。
